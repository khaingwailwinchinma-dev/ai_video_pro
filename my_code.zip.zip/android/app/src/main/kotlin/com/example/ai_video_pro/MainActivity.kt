package com.example.ai_video_pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
